This IPython notebook looplist.ipynb does not require any additional
programs.
