This IPython notebook input.ipynb does not require any additional
programs.
