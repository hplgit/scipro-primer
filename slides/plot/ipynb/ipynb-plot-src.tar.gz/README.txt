This IPython notebook plot.ipynb does not require any additional
programs.
