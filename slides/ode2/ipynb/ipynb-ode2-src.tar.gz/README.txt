This IPython notebook ode2.ipynb does not require any additional
programs.
