This IPython notebook about.ipynb does not require any additional
programs.
