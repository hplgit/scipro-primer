This IPython notebook funcif.ipynb does not require any additional
programs.
