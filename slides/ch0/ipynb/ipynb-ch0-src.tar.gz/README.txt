This IPython notebook ch0.ipynb does not require any additional
programs.
