This IPython notebook formulas.ipynb does not require any additional
programs.
