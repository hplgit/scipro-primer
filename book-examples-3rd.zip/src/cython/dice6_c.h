#include <stdio.h>
#include <stdlib.h>

extern double dice6(int N, int ndice, int nsix);
