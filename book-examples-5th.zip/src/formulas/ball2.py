v0 = 5
g = 9.81
t = 0.6
y = v0*t - 0.5*g*t**2
print y
