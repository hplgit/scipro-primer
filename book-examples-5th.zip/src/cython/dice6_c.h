extern double dice6(int N, int ndice, int nsix);
