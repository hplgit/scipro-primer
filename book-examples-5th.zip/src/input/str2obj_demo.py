from scitools.misc import str2obj
var = str2obj(raw_input('Give value: '))
print 'Got a %s with value %s' % (type(var), var)
