"""
Pysketcher is a simple tool which allows you to create
sketches of, e.g., mechanical systems in Python.
"""
__version__ = '0.1'
__author__ = 'Hans Petter Langtangen <hpl@simula.no>'

from shapes import *
