#!/bin/sh
rm -rf *~ build dice6.c *.so *.o .prof *.html *.tex dice6.capp _dice6* *.pyf dice6_cwrap.c app tmp*
