import sys, pprint
pprint.pprint(sys.argv[1:])
