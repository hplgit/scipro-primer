C = raw_input('C=? ')
C = float(C)
F = 9.0/5*C + 32
print F
