#!/bin/sh
rm -rf tmp* *~ *.ogg *.webm *.mp4 *.flv *.gif