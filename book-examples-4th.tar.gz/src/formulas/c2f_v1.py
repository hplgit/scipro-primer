C = 21
F = (9/5)*C + 32
print F
