from __future__ import print_function
from builtins import input
a = 1
print(a)
print('The value of a is', a)
print('The value of a is', a, end=' ')
b = 2
print('and b=%g' % b)

a = float(input('Give a: '))
a = eval(input('Give a: '))
